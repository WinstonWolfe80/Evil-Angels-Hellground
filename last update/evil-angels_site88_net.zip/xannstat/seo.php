<?php
/**
 * site google
 */
$query = urlencode('site:www.'.$domain);
$res = file('http://www.google.pl/search?q='.$query
           .'&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:pl:official&client=firefox-a');
$google = implode('', $res);
preg_match('/Wyniki(.*) z domeny/', $google, $wyn);
if(isset($wyn)) {
  $string = trim($wyn[1]);
  $google_site = str_replace(',', '', strip_tags(trim(substr($string, strrpos($string, ' ')))));
  unset($wyn);
} else {
  $google_site = 0;
}
unset($res);
/**
 * bl yahoo
 */
$query = urlencode('http://www.'.$domain.'/');
$res = file('http://siteexplorer.search.yahoo.com/advsearch?p='.$query
           .'&bwm=i&bwmo=d&bwmf=u');
$yahoo = implode('', $res);
preg_match('/>Inlinks \((.*)\)</', $yahoo, $wyn);
if(isset($wyn)) {
  $yahoo_bl = intval(str_replace(',', '', $wyn[1]));
  unset($wyn);
} else {
  $yahoo_bl = 0;
}
unset($res);

$q = "INSERT INTO `{$db_seo}` "
    ."(`date`, `google_site`, `yahoo_bl`) "
    ."VALUES ('".date('Y-m-d')."', '{$google_site}', '{$yahoo_bl}') ;";
@mysql_query($q);
?>