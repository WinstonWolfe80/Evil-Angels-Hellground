<?php
set_time_limit(0);

function uwalniacz_akcje() {
  global $db_akcje_uzytkownik;
  global $db_akcje_uzytkownik_data;
  global $db_akcje_wszystkie;

  /**
   * WYSZUKANIE MAKSYMALNEJ I MINIMALNEJ DATY WSROD WPISOW
   * DO TABELI $db_akcje_wszystkie
   */
  $sql = mysql_query(
     "SELECT MIN(`data`) AS `data_min`, MAX(`data`) AS `data_max` "
    ."FROM `{$db_akcje_wszystkie}` ;"
  );
  if(mysql_num_rows($sql) > 0) {
    $data_wstecz = mysql_result($sql, 0, 'data_min');
    $data_do = mysql_result($sql, 0, 'data_max');
  } else {
    return false;
  }
  for($data=$data_wstecz; $data<=$data_do; $data=date('Y-m-d', strtotime('+ 1 day', strtotime($data)))) {
    $sql_m = mysql_query("SELECT * FROM `{$db_akcje_uzytkownik}` ;");
    while($tab_m = mysql_fetch_assoc($sql_m)) {
      if($tab_m['referer'] == '') {
        $q = "SELECT COUNT(*) AS `ilosc` FROM `{$db_akcje_wszystkie}` "
            ."WHERE url = '{$tab_m['url']}' "
            ."AND `data` = '{$data}';";
      } else {
        if($tab_m['referer_dokladnosc'] == '1') {
          if($tab_m['url_dokladnosc'] == '1') {
            $q = "SELECT COUNT(*) AS `ilosc`
                  FROM `{$db_akcje_wszystkie}`
                  WHERE `url` = '{$tab_m['url']}'
                  AND `referer` = '{$tab_m['referer']}' "
                ."AND `data` = '{$data}';";
          } else {
            $q = "SELECT COUNT(*) AS `ilosc`
                  FROM `{$db_akcje_wszystkie}`
                  WHERE `url` LIKE '%".urldecode($tab_m['url'])."%'
                  AND referer = '{$tab_m['referer']}' "
                ."AND `data` = '{$data}';";
          }
        } else {
          if($tab_m['url_dokladnosc'] == '1') {
            $q = "SELECT COUNT(*) AS `ilosc`
                  FROM `{$db_akcje_wszystkie}`
                  WHERE `url` = '{$tab_m['url']}'
                  AND `referer` LIKE '%{$tab_m['referer']}%' "
                ."AND `data` = '{$data}';";
          } else {
            $q = "SELECT COUNT(*) AS `ilosc`
                  FROM `{$db_akcje_wszystkie}`
                  WHERE `url` LIKE '%".urldecode($tab_m['url'])."%'
                  AND `referer` LIKE '%{$tab_m['referer']}%'  "
                ."AND `data` = '{$data}';";
          }
        }
      }
      $sql_s = mysql_query($q);
      $ilosc = mysql_result($sql_s, 0, 'ilosc');
      if($ilosc) {
        mysql_query("UPDATE `{$db_akcje_uzytkownik}`
                     SET `ilosc` = (`ilosc` + {$ilosc})
                     WHERE id = '{$tab_m['id']}' ;" );
        mysql_query("UPDATE `{$db_akcje_uzytkownik_data}` "
          ."SET `ilosc` = (`ilosc` + {$ilosc}) "
          ."WHERE `akcja_id` = '{$tab_m['id']}' "
          ."AND `data` = '{$data}' ;"
        );
        if(mysql_affected_rows() == 0) {
          mysql_query("INSERT INTO `{$db_akcje_uzytkownik_data}` "
            ."(`akcja_id`, `data`, `ilosc`) "
            ."VALUES('{$tab_m['id']}', '{$data}', '{$ilosc}') ;"
          );
        }
      }
    }
  }
  mysql_query("TRUNCATE TABLE `{$db_akcje_wszystkie}` ;");
}

function uwalniacz_ostatnie() {
    global $db_ostatnie;
    $id = array();
    $sql = mysql_query("SELECT `id` FROM `{$db_ostatnie}`
                        ORDER BY `data` DESC LIMIT 0, 500 ;");
    while($row = mysql_fetch_assoc($sql)) {
      $id[] = $row['id'];
    }
    $pozostaw_id = @implode( ', ', $id );
    mysql_query("DELETE FROM `{$db_ostatnie}`
                 WHERE `id` NOT IN ({$pozostaw_id}) ;");
    mysql_query("OPTIMIZE TABLE `{$db_ostatnie}` ;");
}

?>
