<?php
session_start();

require_once('_db_con.php');
require_once('_db_def.php');

//* POCZATEK AUTORYZACJI
$logERROR = 0;
$usuwane_log = time()-(60*60);
mysql_query("DELETE FROM `{$db_admins_log}` WHERE czas < '{$usuwane_log}' ;");

if(isset($_SESSION['SesADMINID']) && !empty($_SESSION['SesADMINID'])) {
    $sql = mysql_query("SELECT * FROM $db_admins_log WHERE identyfikator = '" . $_SESSION['SesIDENTID'] . "' ;");
    while($tab = mysql_fetch_array($sql)) {
        $log['ADMINID'] = $tab['adminid'];
        $log['IDENTID'] = $tab['identyfikator'];
        $log['DATIMID'] = $tab['czas'];
    }
    if( $_SESSION['SesADMINID'] != $log['ADMINID'] ) { $logERROR++; }
} else { $logERROR++; }

if( $logERROR > 0 ) { exit( header( 'Location: index2.php' ) ); }
//* KONIEC AUTORYZACJI

$file = fopen($tempdir.'/backup.sql', 'w+');
$tab = array(
  $db_akcje_uzytkownik,
  $db_akcje_wszystkie,
  $db_blokowane_ip,
  $db_odslony,
  $db_odwiedziny,
  $db_odwiedziny_odslony,
  $db_ostatnie,
  $db_podstrony, 
  $db_referer_ip,
  $db_slowa_kluczowe,
  $db_urls,
  $db_urls_host,
  $db_wyszukiwarki, 
  $db_adresy_slow_kluczowych
);
foreach($tab as $tablica) {
  $sql = mysql_query("SELECT * FROM `{$tablica}` ;");
  while($row = mysql_fetch_assoc($sql)) {
    foreach($row as $v) {
      $w[] = "'".strip_tags($v)."'";
    }
    $val = implode(', ', $w);
    unset($w);
    $pyt = "INSERT INTO `{$tablica}` VALUES ( {$val} ) ;"."\r\n";
    fwrite($file, $pyt);
  }
}
fclose($file);
header( 'Content-Type: application/x-unknown' );
header( 'Content-Disposition: attachment; filename="export.sql"' );
readfile($tempdir.'/backup.sql');

?>