<?php

  function WyswietlStrony( $str, $wszystkich, $link_pocz, $link_kon, $wyswietl = 7 ){
    
    if( $wyswietl < 3 ) $wyswietl = 3;
    if( $wyswietl % 2 == 0 ) $wyswietl++;
    
    $podz = floor( $wyswietl / 2 );
    $od = ( ( $str - $podz ) > 0 ? ( $str - $podz ) : 1 );
    $do = ( ( $str + $podz ) > $wszystkich ? $wszystkich : ( $str + $podz ) );

    $linki['f'] = ( $str > 1 ? $link_pocz . 1 . $link_kon : '' );
    $linki['b'] = ( $str > 1 ? $link_pocz . ( $str - 1 ) . $link_kon : '' );

    for( $i = $od; $i <= $do; $i++ ) {
      if( $i != $str ) $linki['linki'][] = Array( 'n' => $i, 'href' => $link_pocz . $i . $link_kon );
      else $linki['linki'][] = Array( 'n' => $i, 'href' => '' );                        
    }
    
    $linki['n'] = ( $str < $wszystkich ? $link_pocz . ( $str + 1 ) . $link_kon : '' );
    $linki['l'] = ( $str < $wszystkich ? $link_pocz . $wszystkich . $link_kon : '' );
    
    return $linki;
    
  }

?>