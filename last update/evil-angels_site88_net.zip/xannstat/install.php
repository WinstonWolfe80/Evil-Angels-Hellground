<?php
//sprawdzenie poprawnosci praw dostepu do folderow w ktorych ma byc
//kontynuowany proces instalacji
function dostep($tmp = '') {
  $rand_name = !empty($tmp) ? $tmp.'/' : '';
  $rand_name .= sha1(rand(0, 99999).getmypid().microtime());
  $file = fopen($rand_name, 'w+');
  $test = sha1(date('U'));
  if(!fwrite($file, $test)) return false;
  fclose($file);
  $file = fopen($rand_name, 'r');
  $test_read = @fread($file, 1024);
  fclose($file);
  if($test_read != $test) return false;
  if(file_exists($rand_name)) {
    return unlink($rand_name) ? true : false;
  } else {
    return false;
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Plik instalacyjny XannStat</title>
<style type="text/css">
<!--
h2, h4, p, form{ margin:0; padding:0;}
h4{ font-size:16px; margin-bottom:10px;}
p{ line-height:18px;}
p a{color:#666666; text-decoration:none; font-weight:bold;}
p a:hover{ color:#666666; text-decoration:underline}
.error { background: url(img/error_alert.gif) no-repeat #ffe5e5; border:1px #ffacac solid;  font-size:11px; color:#ff0000; padding:5px 7px 5px 35px; line-height:15px; text-align:left;}
.pass { background: url(img/pass_alert.gif) no-repeat #f3faf2; border:1px #ceeac9 solid;  font-size:11px; color:#339900; padding:5px 7px 5px 35px; line-height:15px; text-align:left;}
.warning { background: url(img/warning_alert.gif) no-repeat #fff4e5; border:1px #ffd8a0 solid;  font-size:11px; color:#dfa42b; padding:5px 7px 5px 35px; line-height:15px; text-align:left;}
#log_body{ background: url(img/log_bg.png) repeat-x; margin:0;  font-family:Tahoma, sans-serif; font-size:12px;}
#logo{ width:398px; height:138px; background: url(img/xannstat.jpg) no-repeat;}
#stat_log{ background:#fefbf1; border:1px #fde8cd solid; padding:10px 0; margin:0; }
#tab{font-family:Tahoma, sans-serif; font-size:12px; color:#663300; margin:0; padding:0;}
#tab .input{ background:none; border:0; width:260px; font-size:12px; color:#938243; font-family:Tahoma, sans-serif; text-align:left;}
#tab .inp_bg{background:url(img/form.jpg) no-repeat; height:30px; margin:0; padding:0 10px; border:0; text-align:left}
.log_error{height:25px;}
.bottom{ height:10px;}
img{ border: 0; }
-->
</style>
</head>

<body id="log_body">
<table width="600" align="center" cellpadding="0" cellspacing="0" border="0">
  <tr>
    <td align="center">
      <div id="logo">
       <p style="font-size:10px; font-weight:bold; padding:44px 0 0 202px; margin:0;">INSTALACJA</p>
      </div>
    </td>
  </tr>
  <tr>
    <td id="stat_log" align="center" >

<table width="550" align="center" cellpadding="0" cellspacing="8" border="0" id="tab">
  <?php if( $_GET['krok'] == '' or $_GET['krok'] == '1' ) : ?>
  <tr>
    <td colspan="2" align="left"><p style="padding:0 0 10px 0;">Właśnie rozpocząłeś proces instalacji aplikacji xannSTAT, która pomoże Ci zweryfikować ruch w Twoim serwisie. Prosimy o postępowanie zgodnie z wyświetlającymi się wskazówkami. <br/>Zapraszamy.</p></td>
  </tr>
  <?php endif; ?>
  <?php
  $plik = fopen( 'data.dat', 'r' );
  $dane = explode( '||', fread( $plik, 1024 ) );
  fclose( $plik );
  ?>
  <?php if(dostep() == false || dostep($dane[4]) == false) : ?>
  <tr>
    <td colspan="2" align="left">
      <div class="error">Aby rozpocząć instalację folder statystyk (xannstat) oraz folder użytkownika (<?php echo ( $dane[4] ); ?>) musi mieć przydzielone prawa zapisu. Twoje prawa zapisu do tych folderów są ustawione tak, że nie można pisać w tych folderach (lub w jednym z nich). Aby zmienić dostep musisz skorzystać z programu ftp (np. Total Commander) i ustawić prawa dostępu na pozwalające na zapis w tych folderach (zazwyczaj prawa dostępu 777).
      </div>
    </td>
  </tr>
  </table></td></tr></table></body></html>

<?php exit(); ?>
<?php elseif( $_GET['krok'] == '' or $_GET['krok'] == '1' ) : ?>
<tr>
  <td colspan="2" align="center"><a href="install.php?krok=2"><img src="img/dalej.gif" alt="dalej" /></a></td>
</tr>
<?php endif; ?>


<?php /* KROK 3. */ ?>
<?php if( $_GET['krok'] == '2' ) : ?>
<?php if( empty( $_POST['db_host'] ) or empty( $_POST['db_user'] )  or empty( $_POST['db_pass'] ) or empty( $_POST['db_name'] ) ) : ?>
<form method="post" action="" >
    <input type="hidden" name="kat" value="<?php echo $_POST['kat']; ?>" />
  <tr>
    <td colspan="2" align="left"><h4>2. Konfiguracja bazy danych</h4></td>
  </tr>
  <?php if( $_POST['db_host'] === '' ) : ?>
    <tr><td colspan="2"><div class="error">Nie wypełniono pola <strong>Host</strong></div></td></tr>
  <?php endif; ?>
  <tr>
    <td width="125" align="right">Host:</td>
    <td width="310" class="inp_bg"><input type="text" name="db_host" value="<?php if( $_POST['db_host'] === '' or !isset( $_POST['db_host'] ) ) { echo 'localhost'; } else { echo $_POST['db_host']; } ?>" class="input"/></td>
  </tr>
  <?php if( $_POST['db_user'] === '' ) : ?>
    <tr><td colspan="2"><div class="error">Nie wypełniono pola <strong>Użytkownik</strong></div></td></tr>
  <?php endif; ?>
  <tr>
    <td align="right">Użytkownik:</td>
    <td class="inp_bg"><input type="text" name="db_user" value="<?php echo $_POST['db_user']; ?>" class="input"/></td>
  </tr>
  <?php if( $_POST['db_pass'] === '' ) : ?>
    <tr><td colspan="2"><div class="error">Nie wypełniono pola <strong>Hasło</strong></div></td></tr>
  <?php endif; ?>
  <tr>
    <td align="right">Hasło:</td>
    <td class="inp_bg"><input type="password" name="db_pass" value="<?php echo $_POST['db_pass']; ?>" class="input"/></td>
  </tr>
  <?php if( $_POST['db_name'] === '' ) : ?>
    <tr><td colspan="2"><div class="error">Nie wypełniono pola <strong>Nazwa bazy</strong></div></td></tr>
  <?php endif; ?>
  <tr>
    <td align="right">Nazwa bazy:</td>
    <td class="inp_bg"><input type="text" name="db_name" value="<?php echo $_POST['db_name']; ?>" class="input"/></td>
  </tr>
  <tr>
    <td></td>
    <td align="left"><input type="image" src="img/dalej.gif" /></td>
  </tr>
</form>
<?php else : ?>
<tr>
  <td colspan="2" align="left">
    <h4>Sprawdź czy poprawnie wypełniłeś pola.</h4>
  </td>
</tr>
<form method="post" action="install.php?krok=3" >
<input type="hidden" name="kat" value="<?php echo $_POST['kat']; ?>" />
<tr>
  <td colspan="2" align="left">Dane, które wpisałeś w pola formularza dot. połączenia z bazą danych to:<br /></td>
</tr>
<tr>
  <td width="50%" align="right">host:</td><td align="left"><strong><?php echo $_POST['db_host']; ?></strong></td>
</tr>
<tr>
  <td align="right">user:</td><td align="left"><strong><?php echo $_POST['db_user']; ?></strong></td>
</tr>
<tr>
  <td align="right">pass:</td><td align="left"><strong>*****</strong></td>
</tr>
<tr>
  <td align="right">name:</td><td align="left"><strong><?php echo $_POST['db_name']; ?></strong></td>
</tr>
<tr>
  <td align="right"><a href="install.php?krok=2"><img src="img/wstecz.gif" alt="wstecz" /></a></td>
  <td align="left">
    <input type="hidden" name="db_host" value="<?php echo $_POST['db_host']; ?>" />
    <input type="hidden" name="db_user" value="<?php echo $_POST['db_user']; ?>" />
    <input type="hidden" name="db_pass" value="<?php echo $_POST['db_pass']; ?>" />
    <input type="hidden" name="db_name" value="<?php echo $_POST['db_name']; ?>" />
    <input type="image" src="img/dalej.gif" />
  </td>
</tr>
</form>
<?php endif; ?>
<?php endif; ?>





<?php if( $_GET['krok'] == '3' ) : ?>
<tr>
  <td colspan="2"><h4>Krok 3. Połączenie z serwerem bazy danych</h4></td>
</tr>
<form method="post" action="install.php?krok=4" >
<?php $con = @mysql_connect( $_POST['db_host'], $_POST['db_user'], $_POST['db_pass'] ); ?>
<?php if( !$con ) : ?>
<tr>
  <td colspan="2"><div class="error">Brak połączenia z serwerem bazy <a href="install.php?krok=2"><img src="img/wstecz.gif" alt="wstecz" /></a></div></td>
</tr>
<?php exit(); endif; ?>
<?php $db = @mysql_selectdb( $_POST['db_name'], $con ) ?>
<?php if( !$db ) : ?>
<tr>
  <td colspan="2"><div class="error">Nie mogę wybrać bazy danych <a href="install.php?krok=2"><img src="img/wstecz.gif" alt="wstecz" /></a></div></td>
</tr>
<?php exit(); endif; ?>
<tr>
  <td colspan="2"><div class="pass">Połączono z serwerem bazy danych - kontynuacja instalacji...</div></td>
</tr>
<tr>
  <td align="left" colspan="2"><p>Aplikacja domyślnie stworzy potrzebne tabele w bazie danych z prefiksem <strong>xannstat_</strong>.</p></td>.
</tr>
<tr>
  <td colspan="2">Jesli chcesz możesz utworzyć własny prefiks dla tabeli w bazie danych:</td>
</tr>
<tr>
  <td align="right" width="135">Nowy prefiks:</td>
  <td class="inp_bg"><input type="text" name="prefiks" class="input"/></td>
</tr>
<tr>
  <td colspan="2">Kliknij OK jeżeli chcesz kontynuować instalację.</td>
</tr>
<tr>
  <td colspan="2">
    <div class="warning">UWAGA! Jeżeli powyższe tabele istnieją już w bazie danych to zostaną usunięte...</div>
  </td>
</tr>
<tr>
  <td colspan="2" align="center">
  <input type="hidden" name="db_host" value="<?php echo $_POST['db_host']; ?>" />
  <input type="hidden" name="db_user" value="<?php echo $_POST['db_user']; ?>" />
  <input type="hidden" name="db_pass" value="<?php echo $_POST['db_pass']; ?>" />
  <input type="hidden" name="db_name" value="<?php echo $_POST['db_name']; ?>" />
  <input type="hidden" name="kat" value="<?php echo $_POST['kat']; ?>" />

  <input type="image" src="img/dalej.gif" />
  </td>
</tr>
</form>
<?php endif; ?>

<?php /* KROK 4. */ ?>
<?php if( $_GET['krok'] == '4' ) : ?>
<tr>
  <td colspan="2"><h4>Krok 4. Instalacja została zakończona!</h4></td>
</tr>
<?php $con = @mysql_connect( $_POST['db_host'], $_POST['db_user'], $_POST['db_pass'] ); ?>
<?php if( !$con ) : ?>
<tr>
  <td colspan="2"><div class="error">Utraciłem połączenie z serwerem bazy danych. <a href="install.php?krok=2"><img src="img/wstecz.gif" alt="wstecz" /></a></div></td>
</tr>
<?php exit(); endif; ?>
<?php $db = @mysql_selectdb( $_POST['db_name'], $con ) ?>
<?php if( !$db ) : ?>
<tr>
  <td colspan="2"><div class="error">Nie mogę wybrać bazy danych. <a href="install.php?krok=2"><img src="img/wstecz.gif" alt="wstecz" /></a></div></td>
</tr>
<?php exit(); endif; ?>
<?php

if( $_POST['prefiks'] == '' ) { $prefiks = ''; }
else { $prefiks = $_POST['prefiks'] . '_'; }

$plik = fopen( 'data.dat', 'r' );
$dane = explode( '||', fread( $plik, 1024 ) );
fclose( $plik );
if( file_exists( 'data.dat' ) ) { unlink( 'data.dat' ); }

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_admins`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_admins` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`login` text NOT NULL, "
  ."`pass` varchar(40) NOT NULL default '', "
  ."`sk` varchar(40) NOT NULL default '', "
  ."`email` text NOT NULL, "
  ."`przypomnij_haslo` varchar(40) NOT NULL default '', "
  ."`przypomnij_haslo_data` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_admins_log`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_admins_log` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`adminid` int(11) NOT NULL default '0', "
  ."`identyfikator` text character set utf8 NOT NULL, "
  ."`czas` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_adresy_slow_kluczowych`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_adresy_slow_kluczowych` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`nazwa` varchar(255) character set utf8 NOT NULL, "
  ."`adres` text character set utf8 NOT NULL, "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."`ostatnie_wejscie` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, "
  ."PRIMARY KEY  (`id`), "
  ."KEY `nazwa` (`nazwa`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_akcje_uzytkownik`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_akcje_uzytkownik` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`nazwa` text character set utf8 NOT NULL, "
  ."`url` text character set utf8 NOT NULL, "
  ."`url_nazwa` text character set utf8 NOT NULL, "
  ."`referer` text character set utf8 NOT NULL, "
  ."`referer_nazwa` text character set utf8 NOT NULL, "
  ."`referer_dokladnosc` binary(1) NOT NULL default '', "
  ."`url_dokladnosc` binary(1) NOT NULL default '', "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_akcje_uzytkownik_data`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_akcje_uzytkownik_data` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`akcja_id` int(11) NOT NULL default '0', "
  ."`data` date NOT NULL default '0000-00-00', "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_akcje_wszystkie`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_akcje_wszystkie` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`url` text character set utf8 NOT NULL, "
  ."`referer` text character set utf8 NOT NULL, "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."`data` date NOT NULL default '0000-00-00', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_blokowane_ip`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_blokowane_ip` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`ip` varchar(22) NOT NULL default '', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_odslony`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_odslony` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`data_rok` char(4) NOT NULL default '', "
  ."`data_miesiac` char(2) NOT NULL default '', "
  ."`data_dzien` char(2) NOT NULL default '', "
  ."`tydzien` char(2) NOT NULL default '', "
  ."`dzien_tygodnia` char(1) NOT NULL default '', "
  ."`godzina` char(2) NOT NULL default '', "
  ."`unikalny` int(11) NOT NULL default '0', "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `data_rok` (`data_rok`), "
  ."KEY `data_miesiac` (`data_miesiac`), "
  ."KEY `data_dzien` (`data_dzien`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_odwiedziny`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_odwiedziny` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`data_rok` char(4) NOT NULL default '', "
  ."`data_miesiac` char(2) NOT NULL default '', "
  ."`data_dzien` char(2) NOT NULL default '', "
  ."`tydzien` char(2) NOT NULL default '', "
  ."`dzien_tygodnia` char(1) NOT NULL default '', "
  ."`godzina` char(2) NOT NULL default '', "
  ."`unikalny` int(11) NOT NULL default '0', "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `data_rok` (`data_rok`), "
  ."KEY `data_miesiac` (`data_miesiac`), "
  ."KEY `data_dzien` (`data_dzien`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_odwiedziny_odslony`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_odwiedziny_odslony` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`data_rok` char(4) NOT NULL default '', "
  ."`data_miesiac` char(2) NOT NULL default '', "
  ."`data_dzien` char(2) NOT NULL default '', "
  ."`ilosc_odwiedziny` int(11) NOT NULL default '0', "
  ."`ilosc_odslony` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `data_rok` (`data_rok`), "
  ."KEY `data_miesiac` (`data_miesiac`), "
  ."KEY `data_dzien` (`data_dzien`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_ostatnie`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_ostatnie` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`sesja` text character set utf8 NOT NULL, "
  ."`referer` text character set utf8 NOT NULL, "
  ."`ip` varchar(40) NOT NULL default '', "
  ."`nazwa_hosta` text character set utf8 NOT NULL, "
  ."`podstrony` longtext character set utf8 NOT NULL, "
  ."`datetime` datetime NOT NULL default '0000-00-00 00:00:00', "
	."`datetime_end` datetime NOT NULL default '0000-00-00 00:00:00', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `ip` (`ip`), "
  ."KEY `datetime` (`datetime`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_ostatnie_podstrony`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_ostatnie_podstrony` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`ostatnie_id` int(11) NOT NULL default '0', "
  ."`podstrona` text character set utf8 NOT NULL, "
  ."`datetime` time NOT NULL, "
  ."PRIMARY KEY  (`id`), "
  ."KEY `datetime` (`datetime`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_seo`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_seo` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`date` date NOT NULL, "
  ."`google_site` int(11) NOT NULL default '0', "
  ."`yahoo_bl` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `date` (`date`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_podstrony`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_podstrony` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`nazwa` text character set utf8 NOT NULL, "
  ."`nazwa_edit` text character set utf8 NOT NULL, "
  ."`wizyt` int(11) NOT NULL default '0', "
  ."`wizyt_ostatnia` int(11) NOT NULL default '0', "
  ."`odslon` int(11) NOT NULL default '0', "
  ."`odslon_ostatnia` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_referer_ip`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_referer_ip` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`ip` varchar(22) NOT NULL default '', "
  ."`referer` text character set utf8 NOT NULL, "
  ."`data` int(11) NOT NULL default '0', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_slowa_kluczowe`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_slowa_kluczowe` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`nazwa` varchar(255) character set utf8 NOT NULL, "
  ."`ilosc` int(11) NOT NULL default '0', "
  ."`ostatnia` timestamp NOT NULL default '0000-00-00 00:00:00', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `nazwa` (`nazwa`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_urls`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_urls` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`adres` text character set utf8 NOT NULL, "
  ."`wizyt` int(11) NOT NULL default '0', "
  ."`ostatnia` timestamp NOT NULL default '0000-00-00 00:00:00', "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_urls_host`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_urls_host` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`adres` varchar(255) character set utf8 NOT NULL, "
  ."`wizyt` int(11) NOT NULL default '0', "
  ."`ostatnia` datetime NOT NULL default '0000-00-00 00:00:00', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `adres` (`adres`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_ustawienia`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_ustawienia` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`poz_podstrony` int(11) NOT NULL default '0', "
  ."`poz_urls` int(11) NOT NULL default '0', "
  ."`poz_lapaczfraz` int(11) NOT NULL default '0', "
  ."`poz_ostatnie` int(11) NOT NULL default '0', "
  ."`sprawdzanie` int(11) NOT NULL default '0', "
  ."`ver_i` varchar(10) NOT NULL default '', "
  ."`ver_b` varchar(10) NOT NULL default '', "
  ."`czyszczenie_bazy` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, "
  ."PRIMARY KEY  (`id`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "DROP TABLE IF EXISTS `" . $prefiks . "xannstat_wyszukiwarki`; " );
mysql_query( "CREATE TABLE `" . $prefiks . "xannstat_wyszukiwarki` ( "
  ."`id` int(11) NOT NULL auto_increment, "
  ."`nazwa` varchar(255) character set utf8 NOT NULL, "
  ."`wizyt` int(11) NOT NULL default '0', "
  ."`ostatnia` timestamp NOT NULL default '0000-00-00 00:00:00', "
  ."PRIMARY KEY  (`id`), "
  ."KEY `nazwa` (`nazwa`) "
  .") ENGINE=MyISAM  CHARSET=utf8 COLLATE=utf8_general_ci; " );

mysql_query( "INSERT INTO `" . $prefiks . "xannstat_ustawienia` (`id`, `poz_podstrony`, `poz_urls`, `poz_lapaczfraz`, `poz_ostatnie`, `sprawdzanie`, `ver_i`, `ver_b`) VALUES (1, 30, 30, 30, 10, 0, '1.40', ''); " );
mysql_query( "INSERT INTO `" . $prefiks . "xannstat_admins` (`id`, `login`, `pass`, `sk`, `email`) VALUES (1, '" . $dane[1] . "', '" . $dane[2] . "', '" . $dane[3] . "', '" . $dane[6] . "'); " );

$plik = fopen( '_db_con.php', 'w' );
fwrite( $plik, '<?php $db["host"] = "' . $_POST['db_host'] . '"; $db["user"] = "' . $_POST['db_user'] . '"; $db["pass"] = "' . $_POST['db_pass'] . '"; $db["data"] = "' . $_POST['db_name'] . '";' . "\n" );
fwrite( $plik, '$db["conn"] = mysql_connect($db["host"], $db["user"], $db["pass"]) or die("problem z nawiazaniem polaczenia z baza danych");' );
fwrite( $plik, 'mysql_select_db($db["data"], $db["conn"]) or die("problem z wyborem bazy danych"); mysql_query( "SET CHARSET \'utf8\'" ); ?>' );
fclose( $plik );

$plik = fopen( '_db_def.php', 'w' );
fwrite( $plik, '<?php' . "\n" );
fwrite( $plik, '$tempdir = "' . $dane[4] . '";'  . "\n" );
fwrite( $plik, '$domain = "' . $dane[5] . '";'  . "\n" );
//fwrite( $plik, '$sk1 = "' . $dane[5] . '";'  . "\n" );
//fwrite( $plik, '$sk2 = "' . $dane[6] . '";'  . "\n" );
fwrite( $plik, '$db_admins = "' . $prefiks . 'xannstat_admins";' . "\n" );
fwrite( $plik, '$db_admins_log = "' . $prefiks . 'xannstat_admins_log";' . "\n" );
fwrite( $plik, '$db_akcje_uzytkownik = "' . $prefiks . 'xannstat_akcje_uzytkownik";' . "\n" );
fwrite( $plik, '$db_akcje_uzytkownik_data = "' . $prefiks . 'xannstat_akcje_uzytkownik_data";' . "\n" );
fwrite( $plik, '$db_akcje_wszystkie = "' . $prefiks . 'xannstat_akcje_wszystkie";' . "\n" );
fwrite( $plik, '$db_blokowane_ip = "' . $prefiks . 'xannstat_blokowane_ip";' . "\n" );
fwrite( $plik, '$db_odslony = "' . $prefiks . 'xannstat_odslony";' . "\n" );
fwrite( $plik, '$db_odwiedziny = "' . $prefiks . 'xannstat_odwiedziny";' . "\n" );
fwrite( $plik, '$db_odwiedziny_odslony = "' . $prefiks . 'xannstat_odwiedziny_odslony";' . "\n" );
fwrite( $plik, '$db_ostatnie = "' . $prefiks . 'xannstat_ostatnie";' . "\n" );
fwrite( $plik, '$db_ostatnie_podstrony = "' . $prefiks . 'xannstat_ostatnie_podstrony";' . "\n" );
fwrite( $plik, '$db_seo = "' . $prefiks . 'xannstat_seo";' . "\n" );
fwrite( $plik, '$db_podstrony = "' . $prefiks . 'xannstat_podstrony";' . "\n" );
fwrite( $plik, '$db_referer_ip = "' . $prefiks . 'xannstat_referer_ip";' . "\n" );
fwrite( $plik, '$db_slowa_kluczowe = "' . $prefiks . 'xannstat_slowa_kluczowe";' . "\n" );
fwrite( $plik, '$db_urls = "' . $prefiks . 'xannstat_urls";' . "\n" );
fwrite( $plik, '$db_urls_host = "' . $prefiks . 'xannstat_urls_host";' . "\n" );
fwrite( $plik, '$db_ustawienia = "' . $prefiks . 'xannstat_ustawienia";' . "\n" );
fwrite( $plik, '$db_wyszukiwarki = "' . $prefiks . 'xannstat_wyszukiwarki";' . "\n" );
fwrite( $plik, '$db_adresy_slow_kluczowych = "' . $prefiks . 'xannstat_adresy_slow_kluczowych";' . "\n" );
fwrite( $plik, '?>' . "\n" );
fclose( $plik );
if( file_exists( 'index.php') ) { unlink( 'index.php' ); }
$plik = fopen( 'index.php', 'w+' );
fwrite( $plik, '<?php' . "\n" );
fwrite( $plik, 'header( "Location: index2.php" ); exit();' . "\n" );
fwrite( $plik, '?>' );
fclose( $plik );

?>
<tr>
  <td colspan="2"><div class="pass">Instalacja została pomyślnie zakończona!</div></td>
</tr>
<tr>
  <td colspan="2"><p>Zmień teraz prawa dostępu (chmod) do głównego folderu statystyk na 755.</p></td>
</tr>
<tr>
  <td colspan="2"><div class="warning">Zaniechanie zmiany chmod'ów na 755 grozi poważną utratą bezpieczeństwa Państwa strony internetowej. Jedną z przyczyn może być wykradnięcie danych, które przechowują Państwo na serwerze wirtualnym.</div></td>
</tr>
<tr>
  <td colspan="2"><p>Wraz z pobraniem paczki instalacyjnej został wykreowany plik <strong>info.txt</strong>, w którym zapisany jest Twój login i hasło do statystyk. Po zalogowaniu prosimy o zmianę tych danych. <br />Kliknij <a href="index.php">tutaj</a> aby się zalogować do staytstyk.<br/>Dziękujemy.</p></td>
</tr>

<?php if( file_exists( 'install.php' ) ) { unlink( 'install.php' ); } ?>
<?php endif; ?>

</table>
  </td>
  </tr>
</table>
</body>
</html>