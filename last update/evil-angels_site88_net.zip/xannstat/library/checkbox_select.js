function checkAll() {
  var chx = document.getElementsByName("id[]");
  for(i=0; i<chx.length; i++) {
    if(chx[i].checked == false) chx[i].checked = true;
  }
}

function uncheckAll() {
  var chx = document.getElementsByName("id[]");
  for(i=0; i<chx.length; i++) {
    if(chx[i].checked == true) chx[i].checked = false;
  }
}

function switchAll() {
  var chx = document.getElementsByName("id[]");
  for(i=0; i<chx.length; i++) {
    chx[i].checked = !chx[i].checked;
  }
}

$(document).ready(function(){
  var akcja = $("#akcja option:selected");
  if(akcja.val() == 0) $("form").attr({ action: "admin.php?q=keywords#but", target: "" });
  else if(akcja.val() == 1) $("form").attr({ action: "export.php", target: "_blank" });
  else if(akcja.val() == 2) $("form").attr({ action: "admin.php?q=keywords_delete", target: "" });
  $("#akcja").change(onSelectChange);
})

function onSelectChange(){
  var akcja = $("#akcja option:selected");
  if(akcja.val() == 0) $("form").attr({ action: "admin.php?q=keywords#but", target: "" });
  else if(akcja.val() == 1) $("form").attr({ action: "export.php", target: "_blank" });
  else if(akcja.val() == 2) $("form").attr({ action: "admin.php?q=keywords_delete", target: "" });
}

$(document).ready(function(){
  $("#ban01").click(function () { $("#text_instalacji").text("xannstat_mini_transparent_png.png"); });
  $("#ban02").click(function () { $("#text_instalacji").text("xannstat_mini_white_bw_png.png"); });
  $("#ban03").click(function () { $("#text_instalacji").text("xannstat_mini_white_png.png"); });
  $("#ban04").click(function () { $("#text_instalacji").text("xannstat_mini_black_bw_png.png"); });
  $("#ban05").click(function () { $("#text_instalacji").text("xannstat_mini_black_png.png"); });
});
