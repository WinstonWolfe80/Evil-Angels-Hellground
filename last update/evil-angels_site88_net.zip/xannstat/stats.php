<?php
/**
 * @name      XannStat System Statystyk dla witryn internetowych
 * @copyright Xann Design 2001-2009. Wszelkie prawa zastrzezone.
 * @license   Tresc licencji dostepna w Panelu Administracyjnym
 *            Statystyk XannStat po zalogowaniu w zakladce 'Ustawienia'
 *            oraz pod adresem http://www.xannstat.com/
 */

error_reporting(E_ERROR);
require_once('_db_con.php');
require_once('_db_def.php');

/**
 * USTALENIE ADRESU ODWIEDZIN STRONY
 * ORAZ ADRESU REFERUJACEGO
 */
if(preg_match('/addr=(.*)&ref=/',
              $_SERVER['REQUEST_URI'], $arr1)) {
  $odwiedzanastrona = urldecode($arr1[1]);
  $odwiedzana_strona = parse_url(urldecode($arr1[1]));
} else {
  exit();
}
if(preg_match('/&ref=(.*)&end=end/',
           $_SERVER['REQUEST_URI'], $arr2)) {
  $adresreferujacy = urldecode($arr2[1]);
  $adres_referujacy = parse_url(urldecode($arr2[1]));
}

/**
 * CODOBOWE CZYSZCZENIE BAZY DANYCH
 */
$last_clear = file_exists($tempdir.'/dater.txt') ?
  file($tempdir.'/dater.txt') : array('1970-01-01 01:01:01');
if($last_clear[0] < date('Y-m-d H:i:s', strtotime('-1 week')) && date('G') > 3) {
  require_once('uwalniacz.php');
  uwalniacz_akcje();
  uwalniacz_ostatnie();
  $file = fopen($tempdir.'/dater.txt', 'w+');
  fwrite($file, date('Y-m-d H:i:s'));
  fclose($file);
}
/**
 * Liczenie google site i yahoo bl
 */
$next_check = file_exists($tempdir.'/seo.txt') ?
  file($tempdir.'/seo.txt') : array('1970-01-01 01:01:01');
if(date('Y-m-d H:i:s') > $next_check[0])
{
  require_once('seo.php');
  $file = fopen($tempdir.'/seo.txt', 'w+');
  fwrite($file, date('Y-m-d', strtotime('+1 day')).' 03:01:01');
  fclose($file);
}

/**
 * ZAKONCZENIE DZIALANIA SKRYPTU JEZELI ADRES IP ZNAJDUJE SIE NA LISCIE
 * BLOKOWANYCH ADRESOW
 */
$sql = @mysql_query("SELECT COUNT(`id`) AS `blokowany` FROM `{$db_blokowane_ip}`
                     WHERE `ip` = '{$_SERVER['REMOTE_ADDR']}' ;");
if(mysql_result($sql, 0, 'blokowany') > 0) exit();

$data_rok = date('Y');
$data_miesiac = date('m');
$data_dzien = date('d');
$tydzien = date('W');
$dzien_tygodnia = date('w');
$godzina = date('H');
$dataczas = time();

##tablica przypisujaca stale adresy referujace dla danego uzytkownika
##tablica ta umozliwia poprawna identyfikacje adresu referujacego uzytkownika
##dalej wykorzystywana w akcjach
//usuniecie starych wpisow
@mysql_query("DELETE FROM `{$db_referer_ip}`
              WHERE `data` < (UNIX_TIMESTAMP()-60*60) ;");
//sprawdzenie czy ip znajduje sie w bazie
$sql = @mysql_query("SELECT `id`, `referer` FROM `{$db_referer_ip}`
                     WHERE `ip` = '{$_SERVER['REMOTE_ADDR']}' ;");
//jezeli ip nie znajduje sie w bazie to dodaje ip
if(mysql_num_rows($sql) > 0){
  $id = mysql_result($sql, 0, 'id');
  $adr_referer = mysql_result($sql, 0, 'referer');
} else {
  @mysql_query("INSERT INTO `{$db_referer_ip}`
                VALUES(NULL, '{$_SERVER['REMOTE_ADDR']}',
                '{$adresreferujacy}', UNIX_TIMESTAMP()) ;");
}

if(empty($_COOKIE['odwiedziny'])){
  $sql = @mysql_query("SELECT `id` FROM `{$db_odwiedziny}`
                       WHERE `data_rok` = '{$data_rok}'
                       AND `data_miesiac` = '{$data_miesiac}'
                       AND `data_dzien` = '{$data_dzien}'
                       AND `godzina` = '{$godzina}' ;");
  if(mysql_num_rows($sql) > 0) {
    $id = mysql_result($sql, 0, 'id');
    @mysql_query("UPDATE `{$db_odwiedziny}`
                  SET `ilosc` = (`ilosc` + 1), `unikalny` = '{$dataczas}'
                  WHERE `id` = '{$id}' ;");
    unset($id);
  } else {
    @mysql_query("INSERT INTO `{$db_odwiedziny}`
                  (`data_rok`, `data_miesiac`, `data_dzien`, `tydzien`,
                  `dzien_tygodnia`, `godzina`, `unikalny`, `ilosc`)
                  VALUES ('{$data_rok}', '{$data_miesiac}', '{$data_dzien}',
                  '{$tydzien}', '{$dzien_tygodnia}', '{$godzina}',
                  '{$dataczas}', '1') ;");
  }

  $sql = @mysql_query("SELECT `id` FROM `{$db_odwiedziny_odslony}`
                       WHERE `data_rok` = '{$data_rok}'
                       AND `data_miesiac` = '{$data_miesiac}'
                       AND `data_dzien` = '{$data_dzien}' ;");
  if(mysql_num_rows($sql) > 0) {
    $id = mysql_result($sql, 0, 'id');
    @mysql_query("UPDATE `{$db_odwiedziny_odslony}`
                  SET `ilosc_odwiedziny` = (`ilosc_odwiedziny` + 1)
                  WHERE `id` = '{$id}' ;");
    unset($id);
  } else {
    @mysql_query("INSERT INTO `{$db_odwiedziny_odslony}`
                  (`data_rok`, `data_miesiac`, `data_dzien`, `ilosc_odwiedziny`)
                  VALUES ('{$data_rok}', '{$data_miesiac}', '{$data_dzien}',
                  '1') ;");
  }
}
setcookie('odwiedziny', '1');
$sql = @mysql_query("SELECT `id` FROM `{$db_odslony}` 
                     WHERE `data_rok` = '{$data_rok}' 
                     AND `data_miesiac` = '{$data_miesiac}' 
                     AND `data_dzien` = '{$data_dzien}' 
                     AND `godzina` = '{$godzina}' ;");
if(mysql_num_rows($sql) > 0) {
  $id = mysql_result($sql, 0, 'id');
  @mysql_query("UPDATE `{$db_odslony}` SET `ilosc` = (`ilosc` + 1) 
                WHERE `id` = '{$id}' ;");
  unset($id);
} else {
  @mysql_query("INSERT INTO `{$db_odslony}` 
                (`data_rok`, `data_miesiac`, `data_dzien`, `tydzien`, 
                `dzien_tygodnia`, `godzina`, `unikalny`, `ilosc`) VALUES (
                '{$data_rok}', '{$data_miesiac}', '{$data_dzien}', '{$tydzien}',
                '{$dzien_tygodnia}', '{$godzina}', '{$dataczas}', '1') ;");
}
$sql = @mysql_query("SELECT `id` FROM `{$db_odwiedziny_odslony}` 
                     WHERE `data_rok` = '{$data_rok}' 
                     AND `data_miesiac` = '{$data_miesiac}' 
                     AND `data_dzien` = '{$data_dzien}' ;");
if(mysql_num_rows($sql) > 0) {
  $id = mysql_result($sql, 0, 'id');
  @mysql_query("UPDATE `{$db_odwiedziny_odslony}` 
                SET `ilosc_odslony` = (`ilosc_odslony` + 1) 
                WHERE `id` = '{$id}' ;");
  unset($id);
} else {
  @mysql_query("INSERT INTO `{$db_odwiedziny_odslony}` 
                (data_rok, data_miesiac, data_dzien, ilosc_odslony) 
                VALUES ('{$data_rok}', '{$data_miesiac}', '{$data_dzien}', 
                '1') ;");
}

//rozpoznanie wyszukiwarek
$wyszukiwarka = '';
if($adresreferujacy && isset($adres_referujacy['host'])){
  $host = str_replace('www.', '', $adres_referujacy['host']);
  $wyszukiwarka = (
    $host == 'google.com' ||
    $host == 'google.pl' ||
    $host == 'google.co.uk' ||
    $host == 'google.de' ||
    $host == 'google.lt' ||
    $host == 'google.sk' ||
    $host == 'images.google.com' ||
    $host == 'search.live.com' ||
    $host == 'szukaj.onet.pl' ||
    $host == 'szukaj.wp.pl' ||
    $host == 'search.msn.com' ||
    $host == 'netsprint.pl' ||
    $host == 'search.yachoo.com' ||
    $host == 'gooru.pl' ||
    $host == 'google.interia.pl') ? $host : '';
}

//dodanie wyszukiwarki do bazy
if(!empty($wyszukiwarka)) {
  $q = "UPDATE `{$db_wyszukiwarki}` "
      ."SET `wizyt` = (`wizyt` + 1), `ostatnia` = NOW() "
      ."WHERE `nazwa` = '{$wyszukiwarka}' ;";
  @mysql_query($q);
  if(@mysql_affected_rows() == 0) {
    $q = "INSERT INTO `{$db_wyszukiwarki}` "
        ."(`nazwa`, `wizyt`, `ostatnia`) "
        ."VALUES ('{$wyszukiwarka}', '1', NOW());";
    @mysql_query($q);
  }
}


/**
 * FUNKCJA DODAJACA ADRESY REFERUJACE ORAZ HOSTY ADRESOW REFERUJACYCH
 * (dodano) v.1.30
 */
function referer($db_urls, $db_urls_host, $adresreferujacy, $wyszukiwarka, 
  $adres_referujacy, $odwiedzana_strona)
{

  $referer_host = str_replace('www.', '', $adres_referujacy['host']);
  if($referer_host == str_replace('www.', '', $odwiedzana_strona['host'])) {
    return false;
  }
  //dodanie do bazy hostów
  $q = "UPDATE `{$db_urls_host}` "
      ."SET `wizyt` = (`wizyt` + 1), `ostatnia` = NOW() "
      ."WHERE `adres` = '{$referer_host}';";
  @mysql_query($q);
  if(@mysql_affected_rows() == 0) {
    $q = "INSERT INTO `{$db_urls_host}` (`adres`, `wizyt`, `ostatnia`) "
        ."VALUES('{$referer_host}', '1', NOW()) ;";
    @mysql_query($q);
  }

  //dodanie do bazy konkretnych adresów
  $q = "UPDATE `{$db_urls}` "
      ."SET `wizyt` = (`wizyt` + 1), `ostatnia` = NOW() "
      ."WHERE `adres` = '{$adresreferujacy}';";
  @mysql_query($q);
  if(@mysql_affected_rows() == 0) {
    $q = "INSERT INTO `{$db_urls}` (`adres`, `wizyt`, `ostatnia`) "
        ."VALUES('{$adresreferujacy}', '1', NOW()) ;";
    @mysql_query($q);
  }

}

if(!empty($adresreferujacy) &&
  empty($wyszukiwarka) &&
  isset($adres_referujacy['host']) &&
  $odwiedzana_strona['host'])
{
  referer($db_urls, $db_urls_host, $adresreferujacy, $wyszukiwarka,
    $adres_referujacy, $odwiedzana_strona);
}

//pobranie slow kluczowych
if(isset($wyszukiwarka))
{
  if(!preg_match('/googlebot/', gethostbyaddr($_SERVER['REMOTE_ADDR']))) {
    if($wyszukiwarka == 'google.pl' || $wyszukiwarka == 'google.com') {
      if(preg_match('/q=([^&]*)/', $adres_referujacy['query'], $q))
      {
        $slowa = urldecode($q[1]);
        $kodowanie = mb_detect_encoding($slowa);
        if(!$kodowanie) {
          $konwersja = 'ISO-8859-2';
        } elseif($kodowanie == 'UTF-8') {
          $konwersja = $kodowanie;
        } else {
          $konwersja = '';
        }
        if($konwersja) {
          $slowa = mb_convert_encoding($slowa, 'UTF-8', $konwersja);
        }
        //same slowa kluczowe
        $sql = @mysql_query("SELECT `id` FROM `{$db_slowa_kluczowe}`
                             WHERE `nazwa` = '{$slowa}' ;");
        if(mysql_num_rows($sql) > 0){
          $id = mysql_result($sql, 0, 'id');
          @mysql_query("UPDATE `{$db_slowa_kluczowe}`
                        SET `ilosc` = (`ilosc` + 1), `ostatnia` = NOW()
                        WHERE `id` = '{$id}' ;");
          unset($id);
        } else {
          @mysql_query("INSERT INTO `{$db_slowa_kluczowe}`
                        VALUES ( NULL, '$slowa', 1, NOW()) ;");
        }
        //slowa kluczowe z adresem odwiedzin
        if($odwiedzanastrona && strlen($slowa) > 2 && $slowa != 'www') {
          $sql = @mysql_query("SELECT `id` FROM `{$db_adresy_slow_kluczowych}`
                               WHERE `nazwa` = '{$slowa}'
                               AND `adres` = '{$odwiedzanastrona}' ;");
          if(mysql_num_rows($sql) > 0){
            $id = mysql_result($sql, 0, 'id');
            @mysql_query("UPDATE `{$db_adresy_slow_kluczowych}`
                          SET `ilosc` = (`ilosc` + 1),
                          `ostatnie_wejscie` = NOW()
                          WHERE `id` = {$id} ;");
            unset($id);
          } else {
            @mysql_query("INSERT INTO `{$db_adresy_slow_kluczowych}` VALUES (
                          NULL, '{$slowa}', '{$odwiedzanastrona}', 1, NOW()) ;");
          }
        }
      }
    }
  }
}

?>