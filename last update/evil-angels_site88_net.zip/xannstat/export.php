<?php

include_once( '_db_con.php' );
include_once( '_db_def.php' );

function koniec() {
  echo '<script type="text/javascript">';
  echo 'window.close()';
  echo '</script>';
  exit();
}

preg_match('/http:\/\/([^\/]*)/', $_SERVER['HTTP_REFERER'], $arr);
if($arr[1] != $_SERVER['HTTP_HOST']) koniec();
if(!isset($_POST['zarzadzanie_linkami'])) koniec();
$akcja = isset($_POST['akcja']) ? intval($_POST['akcja']) : 0;
if($akcja != 1) koniec();

if(!isset($_POST['id'])) koniec();
$sql = mysql_query( "SELECT * FROM `{$db_adresy_slow_kluczowych}` WHERE `ID` IN ( " . implode( ', ', $_POST['id'] ) . " ) ;" );
$plik = fopen($tempdir.'/export.txt', 'w');
while( $row = mysql_fetch_assoc( $sql ) ) {
  fwrite( $plik, '"' . $row['nazwa'] . '","' . $row['adres'] . '","1"' . "\r\n" );
}
fclose( $plik );
header( 'Content-Type: application/x-unknown' );
header( 'Content-Disposition: attachment; filename="export.csv"' );
readfile( $tempdir . '/export.txt' );
exit();

?>