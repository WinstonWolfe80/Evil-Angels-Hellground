<?php
session_start();

error_reporting(E_ERROR);

require_once '_db_con.php';
require_once '_db_def.php';

require_once 'stron.php';

//implementacja uwalniaczy
require_once('uwalniacz.php');
uwalniacz_akcje();

require_once 'library/smarty/Smarty.class.php';
$smarty = new Smarty();
$smarty->template_dir = 'tpl/';
$smarty->compile_dir = $tempdir.'/';
$smarty->assign('tempdir', $tempdir);

$q = isset($_GET['q']) ? $_GET['q'] : '';
/**
 * autoryzacja
 */
$logERROR = 0;
$usuwane_log = time()-(60*60);
mysql_query("DELETE FROM `{$db_admins_log}` "
           ."WHERE czas < '{$usuwane_log}' ;");

if(isset($_SESSION['SesADMINID']) && !empty($_SESSION['SesADMINID'])) {
    $sql = mysql_query("SELECT * FROM `{$db_admins_log}` "
                      ."WHERE `identyfikator` = '{$_SESSION['SesIDENTID']}' ;");
    $log = array();
    while($tab = mysql_fetch_array($sql)) {
        $log['ADMINID'] = $tab['adminid'];
        $log['IDENTID'] = $tab['identyfikator'];
        $log['DATIMID'] = $tab['czas'];
    }
    if($_SESSION['SesADMINID'] != $log['ADMINID']) $logERROR++;
} else { $logERROR++; }

if( $logERROR > 0 ) { exit( header( 'Location: index2.php' ) ); }


//Pobranie ustawień
$sql = mysql_query("SELECT *, UNIX_TIMESTAMP() AS `time` "
                  ."FROM `{$db_ustawienia}` ;");
$settings = mysql_fetch_assoc($sql);

/**
 * sprawdzenie wersji obowiazujacej
 */
if($settings['sprawdzanie'] < ($settings['time'] - (60*60*24*7))) {
    $plik = fopen('http://xannstat.com/_xs_/ver.php?dom='. 
                   str_replace('www.', '', $_SERVER['HTTP_HOST']).
                   '&ver=' . $settings['ver_i'] , 'r');
    $ver = fread($plik, 1024);
    fclose($plik);
    mysql_query("UPDATE `{$db_ustawienia}`
                 SET `sprawdzanie` = UNIX_TIMESTAMP(), `ver_b` = '{$ver}' ;");
    $settings['ver_b'] = $ver;
}
$smarty->assign('settings', $settings);

switch($q) {
  case 'seo':
    /**
     * pobranie danych do glownego wykresu
     */
    $year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
    $month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
    $q = "SELECT *, DAY(`date`) AS `day` FROM `{$db_seo}` "
        ."WHERE YEAR(`date`) = '{$year}' "
        ."AND MONTH(`date`) = '{$month}' "
        ."ORDER BY `date` ASC;";
    $sql = mysql_query($q);
    $rows = array();
    while($row = mysql_fetch_assoc($sql)) {
      $rows[$row['day']] = $row;
    }
    $plik = fopen($tempdir.'/seochart_google.txt', 'w');
    for ($i=1; $i<=date('t'); $i++) {
      $string = $i. '. '. date('m'). ';'.
        (isset($rows[$i]) ? $rows[$i]['google_site'] : ''). "\n";
      fwrite($plik, $string);
    }
    fclose($plik);
    $plik = fopen($tempdir.'/seochart_yahoo.txt', 'w');
    for ($i=1; $i<=date('t'); $i++) {
      $string = $i. '. '. date('m'). ';'.
        (isset($rows[$i]) ? $rows[$i]['yahoo_bl'] : ''). "\n";
      fwrite($plik, $string);
    }
    fclose($plik);

    /**
     * pobranie danych do tabelki
     */
    $q = "SELECT *, YEAR(`date`) AS `year`, MONTH(`date`) AS `month` "
        ."FROM `{$db_seo}` ORDER BY `date` ASC;";
    $sql = mysql_query($q);
    $rows = array();
    while($row = mysql_fetch_assoc($sql)) {
      $rows[] = $row;
    }
//    echo print_r($rows);
    $year_dif = date('Y') - $rows[0]['year'] + 1;
    $wykres = array_fill($rows[0]['year'], $year_dif, array_fill(1, 12, array('google_site' => 0, 'yahoo_bl' => 0, 'dzielna' => 0)));
//    echo print_r($wykres, TRUE);
    foreach($rows as $v) {
      $wykres[$v['year']][$v['month']]['google_site'] += $v['google_site'];
      $wykres[$v['year']][$v['month']]['yahoo_bl'] += $v['yahoo_bl'];
      $wykres[$v['year']][$v['month']]['dzielna']++;
    }
//    echo print_r($wykres, TRUE);
    foreach($wykres as $k => $v) {
      for($i=1; $i<=12; $i++) {
        if($wykres[$k][$i]['dzielna'] > 1) {
          $wykres[$k][$i]['google_site'] = ceil($wykres[$k][$i]['google_site'] / $wykres[$k][$i]['dzielna']);
          $wykres[$k][$i]['yahoo_bl'] = ceil($wykres[$k][$i]['yahoo_bl'] / $wykres[$k][$i]['dzielna']);
        }
      }
    }
//    echo print_r($wykres, TRUE);


    $smarty->assign('tempdir', $tempdir);
    $smarty->assign('idgen1', sha1(microtime().rand(0, 9999)));
    $smarty->assign('idgen2', sha1(microtime().rand(0, 9999)));
    $smarty->assign('wykres', $wykres);
    $smarty->assign('site', 'sites/seo/seo.tpl');
    break;

  case 'keywords_delete':
    function key_delete_end() {
      header('Location:admin.php?q=keywords');
      exit();
    }
    /**
     * zbiorowe usuwanie linkow
     */
    if(!isset($_POST['id'])) key_delete_end();
    $q = "DELETE FROM `{$db_adresy_slow_kluczowych}` "
        ."WHERE `ID` IN (".implode(', ', $_POST['id']).") ;";
    mysql_query($q);
    key_delete_end();

  default:
    $data_rok = date('Y');
    $data_miesiac = date('m');
    $data_dzien = date('d');
    $miesiace = array('1'=>'styczeń', '2'=>'luty', '3'=>'marzec',
                      '4'=>'kwiecień', '5'=>'maj', '6'=>'czerwiec',
                      '7'=>'lipiec', '8'=>'sierpień', '9'=>'wrzesień',
                      '10'=>'październik', '11'=>'listopad', '12'=>'grudzień');

    /**
     * pobranie danych do wykresu głównego
     */
    $dzien_wizyty = Array();
    $dzien_odslony = Array();
    $sql = mysql_query("SELECT * FROM `{$db_odwiedziny_odslony}`
                        WHERE `data_rok` = '" . date( 'Y' ) . "'
                        AND `data_miesiac` = '" . date( 'm' ) . "'
                        ORDER BY `data_dzien` ASC ;");
    while($tab = mysql_fetch_assoc($sql)) {
        $dzien_wizyty[ $tab['data_dzien'] ] = $tab['ilosc_odwiedziny'];
        $dzien_odslony[ $tab['data_dzien'] ] = $tab['ilosc_odslony'];
    }
    $plik = fopen( $tempdir . '/wykres_main.txt', 'w' );
    for( $i = 1; $i <= date( 't' ); $i++ ) {
      $k = $i < 10 ? '0'.$i : $i;
      if(!isset($dzien_odslony[$k])) $dzien_odslony[$k] = '';
      if(!isset($dzien_wizyty[$k])) $dzien_wizyty[$k] = '';
      fwrite($plik, $k . '. ' . date('m') . ';' . $dzien_odslony[$k] . ';' . $dzien_wizyty[$k] . "\n");
    }
    fclose( $plik );

    $wizyty = array(); $odslony = array();
    $sql = mysql_query( "SELECT * FROM $db_odwiedziny_odslony ORDER BY data_rok, data_miesiac, data_dzien ;" );
    while( $tab2 = mysql_fetch_assoc( $sql ) ) {
        $wizyty[$tab2['data_rok']][ $tab2[ 'data_miesiac' ] ] += $tab2[ 'ilosc_odwiedziny' ];
        $odslony[$tab2['data_rok']][ $tab2[ 'data_miesiac' ] ] += $tab2[ 'ilosc_odslony' ];
    }

    $q = "SELECT SUM(`ilosc_odwiedziny`) AS `wizyt`, "
        ."SUM(`ilosc_odslony`) AS `odslon` "
        ."FROM `{$db_odwiedziny_odslony}` ;";
    $sql = mysql_query($q);
    $wszystkie = array();
    if($wszystkie = mysql_fetch_assoc($sql));

    $miesiac = Array();
    $sql = mysql_query( "SELECT SUM( ilosc_odwiedziny ) AS wizyt, SUM( ilosc_odslony ) AS odslon FROM $db_odwiedziny_odslony WHERE data_rok = '" . date( 'Y' ) . "' AND data_miesiac = '" . date( 'm' ) . "' ;" );
    if( $miesiac = mysql_fetch_assoc( $sql ) );

    $tydzien = Array();
    $sql = mysql_query( "SELECT SUM( ilosc_odwiedziny ) AS wizyt, SUM( ilosc_odslony ) AS odslon FROM $db_odwiedziny_odslony WHERE data_rok >= '" . date( 'Y', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 7, date( 'Y' ) ) ) . "' AND data_miesiac >=  '" . date( 'm', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 7, date( 'Y' ) ) ) . "' AND data_dzien >= '" . date( 'd', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 7, date( 'Y' ) ) ) . "' ; " );
    if( $tydzien = mysql_fetch_assoc( $sql ) );

    $wczoraj = Array();
    $sql = mysql_query( "SELECT SUM( ilosc_odwiedziny ) AS wizyt, SUM( ilosc_odslony ) AS odslon FROM $db_odwiedziny_odslony WHERE data_rok = '" . date( 'Y', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 1, date( 'Y' ) ) ) . "' AND data_miesiac =  '" . date( 'm', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 1, date( 'Y' ) ) ) . "' AND data_dzien = '" . date( 'd', mktime( 1, 1, 1, date( 'm' ), date( 'd' ) - 1, date( 'Y' ) ) ) . "' ; " );
    if( $wczoraj = mysql_fetch_assoc( $sql ) );

    $pierwszy_wpis = Array();
    $sql = mysql_query( "SELECT * FROM $db_odwiedziny_odslony ORDER BY data_rok, data_miesiac, data_dzien ASC ;" );
    if( $pierwszy_wpis = mysql_fetch_assoc( $sql ) ) {
        $pierwszy_wpis['UNIX'] = date( 'U', mktime( 1, 1, 1, $pierwszy_wpis['data_miesiac'], $pierwszy_wpis['data_dzien'], $pierwszy_wpis['data_rok'] ) );
        $pierwszy_wpis['dni_temu'] = ceil( ( time() - $pierwszy_wpis['UNIX']  ) / 86400 ) ;
    }
    if( isset( $pierwszy_wpis['dni_temu'] ) ) {
        $srednia_wizyt = ceil( $wszystkie['wizyt'] / $pierwszy_wpis['dni_temu'] );
        $srednia_odslon = ceil( $wszystkie['odslon'] / $pierwszy_wpis['dni_temu'] );
    }

    $z_refererow = Array();
    $sql = mysql_query( "SELECT SUM( wizyt ) AS suma FROM $db_urls ;" );
    if( $z_refererow = mysql_fetch_assoc( $sql ) );

    $z_refererow_najczesciej = Array();
    $sql = mysql_query( "SELECT adres, wizyt FROM $db_urls ORDER BY wizyt DESC LIMIT 0, 1 ;" );
    if( $z_refererow_najczesciej = mysql_fetch_assoc( $sql ) );

    $z_wyszukiwarek = Array();
    $sql = mysql_query( "SELECT SUM( wizyt ) AS suma FROM $db_wyszukiwarki ;" );
    if( $z_wyszukiwarek = mysql_fetch_assoc( $sql ) );

    $z_wyszukiwarek_najczesciej = Array();
    $sql = mysql_query( "SELECT nazwa, wizyt FROM $db_wyszukiwarki ORDER BY wizyt DESC LIMIT 0, 1 ;" );
    if( $z_wyszukiwarek_najczesciej = mysql_fetch_assoc( $sql ) );

    /**
     * policzenie liczby online
     */
    $q = "SELECT COUNT(*) AS `online` FROM `$db_ostatnie` "
        ."WHERE `datetime_end` > NOW() - INTERVAL 10 MINUTE ;";
    $sql = mysql_query($q);
    $online = mysql_result($sql, 0, 'online');

    $lop = date( 'Y' ) - date( 'Y', $pierwszy_wpis['UNIX'] ) + 1;
    $smarty -> assign( 'idgen0', md5( uniqid( microtime(), 1 ) ).getmypid() );

    $smarty -> assign( 'dbodwiedziny', $wizyty );
    $smarty -> assign( 'dbodslony', $odslony );

    $smarty -> assign( 'suma_wizyt', $wszystkie['wizyt'] );
    $smarty -> assign( 'suma_wizyt_dzisiaj', $dzien_wizyty[date( 'd' )] );
    $smarty -> assign( 'suma_wizyt_wczoraj', $wczoraj['wizyt'] );
    $smarty -> assign( 'suma_wizyt_miesiac', $miesiac['wizyt'] );
    $smarty -> assign( 'suma_wizyt_tydzien', $tydzien['wizyt'] );
    $smarty -> assign( 'srednia_wizyt_dziennie', $srednia_wizyt );

    $smarty -> assign( 'suma_odslon', $wszystkie['odslon'] );
    $smarty -> assign( 'suma_odslon_dzisiaj', $dzien_odslony[date( 'd' )] );
    $smarty -> assign( 'suma_odslon_wczoraj', $wczoraj['odslon'] );
    $smarty -> assign( 'suma_odslon_miesiac', $miesiac['odslon'] );
    $smarty -> assign( 'suma_odslon_tydzien', $tydzien['odslon'] );
    $smarty -> assign( 'srednia_odslon_dziennie', $srednia_odslon );

    $smarty -> assign( 'z_refererow', $z_refererow['suma'] );
    $smarty -> assign( 'z_refererow_najczesciej', $z_refererow_najczesciej['adres'] );
    $smarty -> assign( 'z_wyszukiwarek', $z_wyszukiwarek['suma'] );
    $smarty -> assign( 'z_wyszukiwarek_najczesciej', $z_wyszukiwarek_najczesciej['nazwa'] );
    $smarty->assign('online', $online);

    $smarty -> assign( 'lop', $lop );
    $smarty -> assign( 'data_rok', $data_rok  );
    $smarty -> assign( 'data_miesiac', $data_miesiac );
    $smarty -> assign( 'data_dzien', $data_dzien );
    $smarty -> assign( 'miesiace', $miesiace );
    $smarty -> assign( 'site', 'sites/index.tpl' );
    break;
  case 'urls':
    $tab = Array();
    $sql = mysql_query("SELECT MAX(`wizyt`) AS `max`
                        FROM `{$db_wyszukiwarki}` ;");
    $max = (mysql_result($sql, 0, 'max') > 0 ? mysql_result($sql, 0, 'max') : 1);

    $sql = mysql_query( "SELECT * FROM $db_wyszukiwarki ORDER BY wizyt DESC ;" );
    while( $tab = mysql_fetch_array( $sql ) ) {
        $tab['wizyt_procent'] = ceil( $tab['wizyt'] / ( $max / 100 ) );
        $wyszukiwarki[] = $tab;
    }
    $smarty -> assign( 'wyszukiwarki', $wyszukiwarki );

    //pobranie liczby wpisow do stronicowania
    $sql = mysql_query( "SELECT COUNT(`id`) AS `wpisow` FROM `{$db_urls_host}` " );
    $wpisow = mysql_result( $sql, 0, 'wpisow' );
    //stronicowanie
    $limit = $settings['poz_urls'];
    $page = ( isset( $_GET['s'] ) > 0 ? intval( $_GET['s'] ) : 1 );
    $wpisow = ( $wpisow > 0 ? $wpisow : 1 );
    $iloscstron = ceil( $wpisow / $limit );
    $od = ( $page - 1 ) * $limit;
    $smarty->assign('WyswietlStrony', WyswietlStrony(
                    $page, $iloscstron, "admin.php?q=urls&s=", ""));

    $sql = mysql_query("SELECT MAX(`wizyt`) AS `max` FROM `{$db_urls_host}` ;");
    $max = (mysql_result($sql, 0, 'max') > 0 ? mysql_result($sql, 0, 'max') : 1);

    $sql = mysql_query( "SELECT * FROM `{$db_urls_host}` ORDER BY `wizyt` DESC LIMIT {$od}, {$limit} ;" );
    while( $tab = mysql_fetch_assoc( $sql ) ) {
        $tab['wizyt_procent'] = ceil( $tab['wizyt'] / ( $max / 100 ) );
        $urls[] = $tab;
    }

    $smarty -> assign( 'urls', $urls );
    $smarty -> assign( 'site', 'sites/urls.tpl' );
    break;

  case 'url':
    $q = "SELECT `adres` FROM `{$db_urls_host}` "
        ."WHERE `id`= '". intval($_GET['id'])."' ;";
    $sql = mysql_query($q);
    if(mysql_num_rows($sql) > 0) {
      $adres = mysql_result($sql, 0, 'adres');
    } else {
      header('Location: index.php?q=urls');
      exit();
    }

    //pobranie liczby wpisow do stronicowania
    $sql = mysql_query( 
      "SELECT COUNT(`id`) AS `wpisow` FROM `{$db_urls}` "
     ."WHERE `adres` LIKE 'http://{$adres}%' "
     ."OR `adres` LIKE 'http://www.{$adres}%' ;");
    $wpisow = mysql_result($sql, 0, 'wpisow');
    //stronicowanie
    $limit = $settings['poz_urls'];
    $page = ( isset( $_GET['s'] ) > 0 ? intval( $_GET['s'] ) : 1 );
    $wpisow = ( $wpisow > 0 ? $wpisow : 1 );
    $iloscstron = ceil( $wpisow / $limit );
    $od = ( $page - 1 ) * $limit;
    $smarty->assign('WyswietlStrony', WyswietlStrony(
                    $page, $iloscstron, "admin.php?q=url&id=".intval($_GET['id'])."&s=", ""));

    $sql = mysql_query(
      "SELECT MAX(`wizyt`) AS `max` FROM `{$db_urls}` "
     ."WHERE `adres` LIKE 'http://{$adres}%' "
     ."OR `adres` LIKE 'http://www.{$adres}%' ;");
    $max = (mysql_result($sql, 0, 'max') > 0 ? mysql_result($sql, 0, 'max') : 1);


    $q = "SELECT * FROM `{$db_urls}` "
        ."WHERE `adres` LIKE 'http://{$adres}%' "
        ."OR `adres` LIKE 'http://www.{$adres}%' "
        ."ORDER BY `wizyt` DESC LIMIT {$od}, {$limit} ;";
    $sql = mysql_query($q);
    while($tab = mysql_fetch_assoc($sql)) {
      $tab['wizyt_procent'] = ceil( $tab['wizyt'] / ( $max / 100 ) );
      $urls[] = $tab;
    }

    $smarty -> assign( 'urls', $urls );
    $smarty -> assign( 'site', 'sites/url.tpl' );
    break;

  case 'searchreferer' :

    if( isset( $_POST['fFraza'] ) ) {
        header( 'Location: admin.php?q=searchreferer&fraza=' . $_POST['fFraza'] );
        exit();
    }

    //pobranie liczby wpisow do stronicowania
    $sql = mysql_query("SELECT COUNT(*) AS `wpisow` FROM `{$db_urls}`
                        WHERE `adres` LIKE '%" . $_GET['fraza'] . "%' ;");
    $wpisow = mysql_result( $sql, 0, 'wpisow' );

    //stronicowanie
    $limit = $settings['poz_urls'];
    $page = ( isset( $_GET['s'] ) > 0 ? intval( $_GET['s'] ) : 1 );
    $wpisow = ( $wpisow > 0 ? $wpisow : 1 );
    $iloscstron = ceil( $wpisow / $limit );
    $od = ( $page - 1 ) * $limit;
    $smarty->assign('WyswietlStrony', WyswietlStrony(
                    $page, $iloscstron, "admin.php?q=searchreferer&s=", "&fraza={$_GET['fraza']}"));

    $wynik = Array();
    $sql = mysql_query( "SELECT MAX(`wizyt`) AS `max` FROM `{$db_urls}` ;" );
    $max = (mysql_result($sql, 0, 'max') > 0 ? mysql_result($sql, 0, 'max') : 1);

    $searchreferer = Array();
    $sql = mysql_query( "SELECT * FROM $db_urls WHERE adres LIKE '%" . $_GET['fraza'] . "%' ORDER BY wizyt DESC LIMIT $od, $limit ;" );
    while( $tab = mysql_fetch_assoc( $sql ) ) {
        $tab['wizyt_procent'] = ceil( $tab['wizyt'] / ( $max / 100 ) );
        $tab['ostatnia'] = date( 'Y-m-d, H:i:s', $tab['ostatnia'] );
        $searchreferer[] = $tab;
    }

    $smarty -> assign( 'searchreferer', $searchreferer );
    $smarty -> assign( 'site', 'sites/searchreferer.tpl' );
    break;

  case 'keywords' :
    if(isset($_GET['delete'])) {
      mysql_query("DELETE FROM `{$db_adresy_slow_kluczowych}`
                   WHERE `id` = ".intval($_GET['delete'])." ;");
      header("Location: {$_SERVER['HTTP_REFERER']}");
      exit();
    }

    $set = (isset($_GET['set']) ? $_GET['set'] : 'keyurl');
    $sort = (isset($_GET['sort']) ? $_GET['sort'] : 'DESC');
    $resort = ($sort == 'DESC' ? 'ASC' : 'DESC');
    $smarty->assign('resort', $resort);
    mysql_query( "DELETE FROM `{$db_slowa_kluczowe}`
                  WHERE nazwa = '' OR nazwa = ' ' ;" );
    mysql_query( "DELETE FROM `{$db_adresy_slow_kluczowych}`
                  WHERE `nazwa` = '' OR `nazwa` = ' ' ;" );

    if( isset( $_POST['keyurl_search'] ) ) {
      header('Location: admin.php?q=keywords&set=keyurl_search&search='.
              urlencode($_POST['keyurl_search']));
      exit();
    }


    if( $set == 'keyurl' ) {
      ##### STRONICOWANIE #####
      //pobranie ilosci wpisow
      $sql = mysql_query("SELECT COUNT(`id`) AS `wpisow`
                          FROM `{$db_adresy_slow_kluczowych}` ;");
      $wpisow = (mysql_result($sql, 0, 'wpisow') > 0 ?
                 mysql_result($sql, 0, 'wpisow') : 1 );
      //pobranie limitu wyswietlanych wynikow
      $limit = $settings['poz_lapaczfraz'];
      //wyliczenie ilosci podstron
      $iloscstron = ceil($wpisow/$limit);
      //pobranie informacji o aktualnej stronie
      $page = (isset($_GET['page']) > 0 ? intval($_GET['page']) : 1);
      $od = ($page-1)*$limit;
      $smarty->assign('WyswietlStrony', WyswietlStrony($page, $iloscstron,
                      'admin.php?q=keywords&page=', '&sort='.$sort));

      $sql = mysql_query("SELECT MAX( `ilosc` ) AS `max`
                          FROM `{$db_adresy_slow_kluczowych}` ;");
      $max = (mysql_num_rows($sql) > 0 ? mysql_result($sql, 0, 'max') : 0);

      $slowa_kluczowe_adresy = array();
      $sql = mysql_query("SELECT * FROM `{$db_adresy_slow_kluczowych}` 
                          ORDER BY `ilosc` {$sort} LIMIT {$od}, {$limit} ;");
      while( $row = mysql_fetch_assoc( $sql ) ) {
        $row['procent'] = ceil( $row['ilosc'] / ( $max / 100 ) );
        $slowa_kluczowe_adresy[] = $row;
      }

      $smarty->assign('SlowaKluczoweAdresy', $slowa_kluczowe_adresy);
      $smarty->assign('site', 'sites/keywords/keyurl.tpl');
      break;
    }

    if($set == 'keyurl_search') {
      //pobranie ilosci wpisow
      $sql = mysql_query("SELECT COUNT(`id`) AS `wpisow`
                          FROM `{$db_adresy_slow_kluczowych}`
                          WHERE `nazwa` LIKE '%".urldecode($_GET['search'])."%'
                            OR `adres` = '".urldecode($_GET['search']). "'
                            OR `adres` = '".urldecode( $_GET['search'])."/' ;");
      $wpisow = (mysql_result($sql, 0, 'wpisow') > 0 ?
                 mysql_result($sql, 0, 'wpisow') : 1 );
      //pobranie limitu wyswietlanych wynikow
      $limit = $settings['poz_lapaczfraz'];
      //wyliczenie ilosci podstron
      $iloscstron = ceil($wpisow/$limit);
      //pobranie informacji o aktualnej stronie
      $page = (isset($_GET['page']) > 0 ? intval($_GET['page']) : 1);
      $od = ($page-1)*$limit;
      $smarty->assign('WyswietlStrony', WyswietlStrony($page, $iloscstron,
                      'admin.php?q=keywords&set=keyurl_search&page=',
                      '&sort='.$sort.'&search='.$_GET['search']));

      $sql = mysql_query("SELECT MAX(`ilosc`) AS `max`
                          FROM `{$db_adresy_slow_kluczowych}` ;");
      $max = (mysql_num_rows($sql) > 0 ? mysql_result($sql, 0, 'max') : 0);

      $sql = mysql_query("SELECT * FROM `{$db_adresy_slow_kluczowych}`
                          WHERE `nazwa` LIKE '%".urldecode($_GET['search'])."%'
                            OR `adres` = '".urldecode($_GET['search']). "'
                            OR `adres` = '".urldecode( $_GET['search'])."/'
                          ORDER BY `ilosc` {$sort} LIMIT {$od}, {$limit} ;");
      while( $row = mysql_fetch_assoc( $sql ) ) {
        $row['procent'] = ceil( $row['ilosc'] / ( $max / 100 ) );
        $slowa_kluczowe_adresy[] = $row;
      }
      $smarty->assign('SlowaKluczoweAdresy', $slowa_kluczowe_adresy);
      $smarty->assign('site', 'sites/keywords/keyurl.tpl');
      break;
    }

    break;

  case 'ustawienia':
    $akcja = (isset($_GET['akcja']) ? $_GET['akcja'] : '');
    switch($akcja) {
      default:
        preg_match('/\/(.*?)\//', $_SERVER['REQUEST_URI'], $tab);
        $smarty->assign('install', $_SERVER['HTTP_HOST'].'/'.$tab[1]);
        $smarty->assign('sk1', $sk1);
        $smarty->assign('sk2', $sk2);
        $smarty->assign('site', 'sites/config/install.tpl');
        break;

      case 'license':
        $smarty->assign('site', 'sites/config/license.tpl');
        break;

      case 'dane':
        $smarty->assign('site', 'sites/config/dane.tpl');
        break;

      case 'dane_wczytaj':
        function wczytaj_dane() {
          if(!isset($_FILES['file']['tmp_name'])) return false;
          if(substr($_FILES['file']['name'], -4) != '.sql') return false;
          if($_FILES['file']['size'] == 0) return false;
          $data = file($_FILES['file']['tmp_name']);
          foreach($data as $v) @mysql_query(rtrim($v));
        }
        wczytaj_dane();
        header('Location: admin.php?q=ustawienia&akcja=dane');
        exit();

      case 'dane_reset':
        mysql_query("TRUNCATE TABLE `{$db_akcje_uzytkownik}` ;");
        mysql_query("TRUNCATE TABLE `{$db_akcje_wszystkie}` ;");
        mysql_query("TRUNCATE TABLE `{$db_blokowane_ip}` ;");
        mysql_query("TRUNCATE TABLE `{$db_odslony}` ;");
        mysql_query("TRUNCATE TABLE `{$db_odwiedziny}` ;");
        mysql_query("TRUNCATE TABLE `{$db_odwiedziny_odslony}` ;");
        mysql_query("TRUNCATE TABLE `{$db_ostatnie}` ;");
        mysql_query("TRUNCATE TABLE `{$db_podstrony}` ;");
        mysql_query("TRUNCATE TABLE `{$db_referer_ip}` ;");
        mysql_query("TRUNCATE TABLE `{$db_slowa_kluczowe}` ;");
        mysql_query("TRUNCATE TABLE `{$db_urls}` ;");
        mysql_query("TRUNCATE TABLE `{$db_urls_host}` ;");
        mysql_query("TRUNCATE TABLE `{$db_wyszukiwarki}` ;");
        mysql_query("TRUNCATE TABLE `{$db_adresy_slow_kluczowych}` ;");
        header("Location: admin.php?q=ustawienia&akcja=dane");
        exit();

      case 'userpass':
        if(isset($_POST['submit'])) {
          if($_POST['user1'] == $_POST['user2'] && !empty($_POST['user1'])) {
            mysql_query("UPDATE `{$db_admins}` SET `login` = '{$_POST['user1']}'
                         WHERE `id` = '{$log['ADMINID']}' ;");
          }
          if($_POST['pass1'] == $_POST['pass2'] && !empty($_POST['pass1'])) {
            mysql_query("UPDATE `{$db_admins}`
                         SET `pass` = '".sha1($_POST['pass1'])."'
                         WHERE id = '{$log['ADMINID']}' ;");
          }
          if($_POST['email1'] == $_POST['email2']) {
            mysql_query("UPDATE `{$db_admins}` 
                         SET `email` = '{$_POST['email1']}'
                         WHERE id = '{$log['ADMINID']}' ;");
          }
          header("Location: {$_SERVER['HTTP_REFERER']}");
          exit();
        }

        $sql = mysql_query("SELECT * FROM `{$db_admins}`
                            WHERE `id` = '{$log['ADMINID']}' ;");
        $admininfo = mysql_fetch_assoc($sql);

        $smarty -> assign( 'admininfo', $admininfo );
        $smarty -> assign( 'site', 'sites/config/userpass.tpl' );
        break;

      case 'pagination':
        if(isset($_POST['submit'])) {
          if($_POST['fPodstrony'] >= '10' && $_POST['fPodstrony'] <= '100' &&
             $_POST['fUrls'] >= '10' && $_POST['fUrls'] <= '100' &&
             $_POST['fWyszukiwarki'] >= '10' &&
             $_POST['fWyszukiwarki'] <= '100' &&  $_POST['fOstatnie'] >= '10' &&
             $_POST['fOstatnie'] <= '100' ) {
            mysql_query("UPDATE `{$db_ustawienia}` SET
                         `poz_podstrony` = '{$_POST['fPodstrony']}',
                         `poz_urls` = '{$_POST['fUrls']}',
                         `poz_lapaczfraz` = '{$_POST['fWyszukiwarki']}',
                         `poz_ostatnie` = '{$_POST['fOstatnie']}' ;");
          }
          header("Location: {$_SERVER['HTTP_REFERER']}");
          exit();
        }
        $sql = mysql_query("SELECT * FROM `{$db_ustawienia}` ;");
        $smarty->assign('ustaw', mysql_fetch_array($sql));
        $smarty->assign('site', 'sites/config/pagination.tpl');
        break;

      case 'ipban':
        if(isset($_POST['ip'])) {
          if(preg_match('/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', $_POST['ip'])) {
            mysql_query("INSERT INTO `{$db_blokowane_ip}` (`ip`)
                         VALUES ('{$_POST['ip']}') ;");
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit();
          }
        }
        if(isset($_GET['id'])) {
          mysql_query("DELETE FROM `{$db_blokowane_ip}`
                       WHERE `id` = ".intval($_GET['id'])." ;");
          header("Location: {$_SERVER['HTTP_REFERER']}");
          exit();
        }
        $blokowane_ip = array();
        $sql = mysql_query("SELECT * FROM `{$db_blokowane_ip}`
                            ORDER BY `id` DESC ;");
        while($tab = mysql_fetch_assoc($sql)) { 
          $blokowane_ip[] = $tab;
        }
        $smarty -> assign( 'blokowane_ip', $blokowane_ip );
        $smarty -> assign( 'site', 'sites/config/ipban.tpl' );
        break;
    }
    break;

  case 'wyloguj':
    mysql_query("DELETE FROM `{$db_admins_log}`
                 WHERE `identyfikator` = '{$_SESSION['SesIDENTID']}' ;");
    header( 'Location: index2.php' );
    exit();

  case 'view':
    $smarty->assign('site', 'sites/wersja_pro.tpl');
    break;
  case 'podstrony':
    $smarty->assign('site', 'sites/wersja_pro.tpl');
    break;
  case 'akcje':
    $smarty->assign('site', 'sites/wersja_pro.tpl');
    break;
  case 'ostatnie':
    $smarty->assign('site', 'sites/wersja_pro.tpl');
    break;
}
$smarty -> display('index.tpl');

?>