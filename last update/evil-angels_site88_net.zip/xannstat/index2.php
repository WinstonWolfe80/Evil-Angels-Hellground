<?php
session_start();
error_reporting(E_ERROR|E_WARNING);

require_once '_db_con.php';
require_once '_db_def.php';

//mysql_query("UPDATE `xs__xannstat_admins` SET pass = SHA1('pass') WHERE id = 1 ;");
//
//echo sha1('pass');
//
//$sql = mysql_query("SELECT * FROM `xs__xannstat_admins` ");
//echo print_r(mysql_fetch_assoc($sql), TRUE);




require_once 'library/smarty/Smarty.class.php';
$smarty = new Smarty();
$smarty->template_dir = 'tpl/';
$smarty->compile_dir = $tempdir.'/';

$sql = mysql_query("SELECT `przypomnij_haslo_data`, `przypomnij_haslo`
                    FROM `{$db_admins}` WHERE `id` = 1 ;");
if(mysql_result($sql, 0, 'przypomnij_haslo_data') < date('Y-m-d H:i:s', strtotime('- 1 day')) &&
   mysql_result($sql, 0, 'przypomnij_haslo') != '') {
  mysql_query("UPDATE `{$db_admins}` SET
               `przypomnij_haslo_data` = NOW(),
               `przypomnij_haslo` = ''
               WHERE `id` = 1 ;");
}
if(isset($_GET['zmiana'])) {
  $sql = mysql_query("SELECT `przypomnij_haslo`, `email` FROM `{$db_admins}`
                      WHERE `id` = 1 ;");
  if(mysql_result($sql, 0, 'przypomnij_haslo') == $_GET['zmiana'] && !empty($_GET['zmiana'])) {
    $sk = sha1(microtime().rand(1, 99999).getmypid());
    $new_pass = substr($sk, 5, 6);

    $EmailDo = mysql_result($sql, 0, 'email');
    $url = parse_url( $_SERVER['HTTP_REFERER'] );
    $emailsubject = '[XannStat] ' . $url['host'] . ' - Hasło zostało zmienione' .
                    ' (' . date( 'Y-m-d H:i:s' ) . ')';
    $EmailOd = 'no-reply@'.$url['host'];
    $eol = "\r\n";
    $headers  = "From: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Reply-To: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Return-Path: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Message-ID: <" . date( 'Y-m-d_H:i:s' ) . "TheSystem@{$_SERVER['SERVER_NAME']}>{$eol}";
    $headers .= 'X-Mailer: PHP v' . phpversion() . $eol;
    $headers .= "MIME-Version: 1.0{$eol}";
    $headers .= "Content-Type: text/plain; charset=utf-8{$eol}";
    $msg = 'Hasło w systemie XannStat dla domeny '.$_SERVER['HTTP_HOST'].$eol;
    $msg .= 'zostało zmienione.'.$eol;
    $msg .= "Nowe hasło: {$new_pass}";
    mysql_query("UPDATE `{$db_admins}` SET `pass` = '".sha1($new_pass)."'
                 WHERE `id` = 1 ;");
    mail($EmailDo, "=?UTF-8?B?" . base64_encode( $emailsubject ) . "?=", $msg, $headers);

    header( "Location: index2.php?a=zmieniono" );
    exit();
  } else {
    header( "Location: index2.php?a=niezmieniono" );
    exit();
  }
}

if(isset($_POST['email'])) {
  $sql = mysql_query("SELECT `email` FROM `{$db_admins}` WHERE `id` = 1 ;");
  if(mysql_result($sql, 0, 'email') == $_POST['email']) {
    $sk = sha1(microtime().rand(1, 99999));
    mysql_query("UPDATE `{$db_admins}` SET
                 `przypomnij_haslo` = '{$sk}',
                 `przypomnij_haslo_data` = NOW()
                 WHERE `id` = 1 ;");
    $addr = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?zmiana='.$sk;
    $EmailDo = mysql_result($sql, 0, 'email');
    $url = parse_url( $_SERVER['HTTP_REFERER'] );
    $emailsubject = '[XannStat] ' . $url['host'] . ' - Zmiana hasła' .
                    ' (' . date( 'Y-m-d H:i:s' ) . ')';
    $EmailOd = 'no-reply@'.str_replace('www.', '', $url['host']);
    $eol = "\r\n";
    $headers  = "From: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Reply-To: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Return-Path: {$EmailOd} <{$EmailOd}>{$eol}";
    $headers .= "Message-ID: <" . date( 'Y-m-d_H:i:s' ) . "TheSystem@{$_SERVER['SERVER_NAME']}>{$eol}";
    $headers .= 'X-Mailer: PHP v' . phpversion() . $eol;
    $headers .= "MIME-Version: 1.0{$eol}";
    $headers .= "Content-Type: text/plain; charset=utf-8{$eol}";
    $msg = 'Aby zmienić hasło w systemie XannStat dla domeny '.$_SERVER['HTTP_HOST'].$eol;
    $msg .= 'naciśnij na link aktywacyjny:'.$eol;
    mail($EmailDo, "=?UTF-8?B?" . base64_encode( $emailsubject ) . "?=", $msg.$addr, $headers);

    header( "Location: index2.php?a=wyslano" );
    exit();
  } else {
    header( "Location: index2.php?a=niewyslano" );
    exit();
  }
}

if( isset( $_POST['LOGIN'] ) && !empty( $_POST['PASS'] ) ) {
    
    $identyfikator = md5( uniqid( microtime(), 1 ) ) . getmypid();

    $db = array();
    $sql = mysql_query("SELECT * FROM $db_admins "
                      ."WHERE login = '" . strip_tags(trim($_POST['LOGIN'])) . "' ;");
    if( $db = mysql_fetch_assoc( $sql ) );
    if ( sha1( $_POST['PASS'] ) === $db['pass'] && sha1( str_replace( 'www.', '', $_SERVER['HTTP_HOST'] ) ) === $db['sk'] ) {
        mysql_query( "INSERT INTO $db_admins_log VALUES ( NULL, '" . $db['id'] . "', '$identyfikator', UNIX_TIMESTAMP() );" );

        $_SESSION['SesADMINID'] = $db['id'];
        $_SESSION['SesIDENTID'] = $identyfikator;
                
        header( 'Location: admin.php' );
        exit();
        
    } else { $smarty -> assign( 'error', '1' ); }
}
$smarty -> display( 'logowanie.tpl' );

?>
